/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicios;

/**
 *
 * @author Alunos
 */
public class Calculadora {
   public Integer multiplicacao(int A, int B){
       return A * B;
   }
   
   public Integer soma(int A, int B){
       return A + B;
   }
   
   public Integer subtracao(int A, int B){
       return A - B;
   }
   
   public Integer divisao(int A, int B){
       return A / B;
   }
           
}
